
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <!--favicon-->
    <link rel="icon" href="{{ asset('images/favicon.png') }}" type="image/png" />

    <title>Zuuro ::| - We provide you
                        best and easy
                        services that
                        make life easier.</title>

    <!-- Bootstrap core CSS -->
    <link href="{{ asset('vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="{{ asset('css/fontawesome.css') }}">
    <link rel="stylesheet" href="{{ asset('css/templatemo-eduwell-style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/owl.css') }}">
    <link rel="stylesheet" href="{{ asset('css/lightbox.css') }}">

  </head>

<body>


  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                      <a href="index.html" class="logo">
                          <img src="{{ asset('images/templatemo-eduwell.png') }}" alt="EduWell Template">
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li class="scroll-to-section"><a href="/" class="active">Home</a></li>
                          <li class="scroll-to-section"><a href="user_services">Services</a></li>
                          <li class="scroll-to-section"><a href="user_about_us">About Us</a></li>
                          <li class="scroll-to-section"><a href="/countact_us">Contact-us</a></li> 
                          <li class="scroll-to-section"><a href="/login" target="_blank">Login</a></li> 
                      </ul>        
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <!-- ***** Main Banner Area Start ***** -->
  <section class="main-banner" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center">
          <div class="header-text">
            <h6>Welcome to <strong>Zuuro!</strong>   </h6>
            <h2>We provide best & easy mobile recharge & mobile recharge loan solutions that makes life <em>easier!</em></h2>
            <div class="main-button-gradient">
              <div class="scroll-to-section"><a href="{{ route('register') }} ">Sign Up Now</a></div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="right-image">
            <img src="/{{ asset('images/banner-right-image.png') }}" alt="">
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->


  <section class="simple-cta" id="about_us">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 offset-lg-1">
          <div class="left-image">
            <img src="/{{ asset('images/contact-us.jpg') }}" alt="">
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <h6>Brief About Zuuro!</h6>
          <p>Zuuro is a leading mobile recharge company in Nigeria that provides microcredit as loans to the people
            who have a low balance on their Globe or TM sim card worldwide.</p>
            <p>Zuuro was founded to improve people’s lives by helping those with less, gain access to more.</p>
            <p> Our aim has been to build & run the safest, simplest, most effective & convenient top-up service as loan,
            in partnership with the best operators and platforms. We provide more secure top-up loans to more
            countries, through more operators, helping people all around the world to send little bytes of happiness
            to their loved ones on loan in the blink of an eye.</p>
            <p>We believe in giving mobile recharge loans to our customers when they have low balance on there sim
            help them solve there emergency needs in calling or accessing the internet.</p>
          
        </div>
      </div>
    </div>
  </section>



  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

    <script src="{{ asset('js/isotope.min.js') }}"></script>
    <script src="{{ asset('js/owl-carousel.js') }}"></script>
    <script src="{{ asset('js/lightbox.js') }}"></script>
    <script src="{{ asset('js/tabs.js') }}"></script>
    <script src="{{ asset('js/video.js') }}"></script>
    <script src="{{ asset('js/slick-slider.js') }}"></script>
    <script src="{{ asset('js/custom.js') }}"></script>
 
</body>

</html>