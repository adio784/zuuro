

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Transaction /</span> Fund History</h4>

        <div class="row">
          <div class="col-md-12">
            <div class="card mb-4">
            <!-- <h5 class="card-header">Data</h5> -->
            <!-- Data -->
            
                <hr class="my-0" />
                <div class="card-body">
                    <div class="row"> 
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="table-responsive text-wrap">
                            <table class="table" id="example">
                    <thead>
                      <tr>
                        <th>TransactionRef</th>
                        <th>Amount</th>
                        <th> Payment ID</th>
                        <th>Message</th>
                        <th>Date</th>
                        
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $__currentLoopData = $LoanInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                      <tr>
                        <td>
                          <i class="fab fa-bootstrap fa-lg text-primary me-3"></i> <strong><?php echo e($item->reference); ?></strong>
                        </td>
                        <td><span class="badge bg-primary"> <?php echo e(number_format($item->amount)); ?></span></td>
                        <td><span class="badge bg-warning text-white"> <?php echo e($item->payment_id); ?> </span></td> 
                        <td><span class="badge bg-label-info me-1 text-dark"><?php echo e($item->message); ?></span></td>

                        <td><?php echo e($item->created_at); ?></td>
                        
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- /Account -->
            </div>
            
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/user/fund_history.blade.php ENDPATH**/ ?>