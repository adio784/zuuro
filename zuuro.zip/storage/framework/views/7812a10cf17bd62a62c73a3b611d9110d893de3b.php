

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account Settings /</span> <a href="<?php echo e(route('manage_users_page')); ?>"> User </a> </h4>

              <div class="row">
                <div class="col-md-12">
                  <ul class="nav nav-pills flex-column flex-md-row mb-3">
                    <li class="nav-item">
                      <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Account</a>
                    </li>
                  </ul>
                  <div class="card mb-4">
                    <h5 class="card-header"><?php echo e($getUserInfo->name); ?></h5>
                    <!-- Account -->
                    <div class="card-body">
                    <hr class="my-0" />
                    <div class="card-body">
                        <div class="row">
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">FULLNAME: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->name); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">USERNAME: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->username); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">EMAIL: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->email); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">GENDER: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->gender); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">MOBILE NUMBER: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->phone_number); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">ADDRESS: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->address .', '. $getUserInfo->country); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">ZIPCODE: </h6>
                                <h5 class="card-header p-1"><?php echo e($getUserInfo->zipcode); ?></h5>
                                </div>
                           </div>
                          </div>
                          <div class="mb-3 col-md-6">
                           <div class="card p-3">
                                <div class="form-group">
                                <h6 class="card-header p-1">DATE OF BIRTH: </h6>
                                <h5 class="card-header p-1"><?php echo e(date('D, F g, Y', strtotime($getUserInfo->dob))); ?></h5>
                                </div>
                           </div>
                          </div>
                        </div>

                    </div>
                    <!-- /Account -->
                  </div>
                  
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/admin/view_user_info.blade.php ENDPATH**/ ?>