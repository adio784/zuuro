

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"> Top-up/</span> Receipt</h4>

              <div class="row">
                <div class="col-md-12">
                  <div class="card mb-4">
                    <h5 class="card-header"><strong>  Transaction Receipt </strong></h5>
                    <!-- Data -->
                    
                    <hr class="my-0" />
                    <div class="card-body">
                        <div class="table">
                            <table id="example" class="display table-bordered" style="width:50%">
                                <thead>
                                    <th colspan="2" class="center"> 
                                        <img width="50" viewbox="0 0 25 42" version="1.1" src="<?php echo e(asset('images/favicon.png')); ?>">
                                        <p>Zuuro Telecommunications</p>
                                    </th>
                                </thead>
                                <tbody>
                                    <tr><th colspan="2" class="center"> Transaction Details </th></tr>
                                        
                                    <tr>
                                        <th>TransactionRef</th>
                                        <td> <?php echo e($receiptRespose['TransferId']['TransferRef']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Mobile Recharge</th>
                                        <td> <?php echo e($nwkDetail['transTopup']); ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Network</th>
                                        <td> <?php echo e($nwkDetail['nwkName']); ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Number</th>
                                        <td> <?php echo e($receiptRespose['AccountNumber']); ?> </td>
                                    </tr>
                                    <?php if($nwkDetail['transTopup'] == 'Airtime'): ?>
                                    <tr>
                                        <th>Received Value</th>
                                        <td> <?php echo e(number_format($receiptRespose['Price']['ReceiveValue'])); ?> </td>
                                    </tr>
                                    <?php else: ?>
                                    <tr>
                                        <th>Data Plan</th>
                                        <td> <?php echo e($nwkDetail['dataPlan']); ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Amount</th>
                                        <td> <?php echo e(number_format($receiptRespose['Price']['ReceiveValue'])); ?> </td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th>Processing State</th>
                                        <td> <?php if($receiptRespose['ProcessingState'] == 'Complete'): ?> 
                                            <span class="badge badge-success text-success"><?php echo e('Successful'); ?> </span>
                                            <?php else: ?> <span class="badge badge-danger text-danger"><?php echo e($receiptRespose['ProcessingState']); ?> </span>
                                            <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Date Completed</th>
                                        <td> <?php echo e($receiptRespose['CompletedUtc']); ?> </td>
                                    </tr>
                                </tbody>
                            </table>    
                        </div>
                        <div class="row">
                            <div class="col-md-4 offset-3 mt-4 mb-4">
                                <div class="form-group">
                                    <a href="#" class="btn btn-success" id="print_btn"> Print </a>
                                    <a onclick="window.print()" class="btn btn-warning text-dark"> Download </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Account -->
                  </div>
                 
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<!-- <th>TransferId</th>
                                <th>SkuCode</th>
                                <th>TransferRef</th>
                                <th>DistributorRef</th>
                                <th>ReceiveValue</th>
                                <th>ReceiveCurrencyIso</th>
                                <th>SendValue</th>
                                <th>SendCurrencyIso</th>
                                <th>CommissionApplied</th>
                                <th> StartedUtc</th>
                                <th> CompletedUtc</th>
                                <th> ProcessingState</th>
                                <th>ReceiptText</th>
                                <th> AccountNumber</th> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/user/loan_airtime_receipt.blade.php ENDPATH**/ ?>