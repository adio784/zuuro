

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Manage / </span> Users</h4>

        <div class="row">
          <div class="col-md-12">
            <div class="card mb-4">
            <!-- <h5 class="card-header">Data</h5> -->
            <!-- Data -->
            
                <hr class="my-0" />
                <div class="card-body">
                    <div class="row"> 
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="table-responsive text-wrap">
                            <table class="table" id="table_id">
                          <div id="result">
                              <?php if(Session::get('success')): ?>
                                  <div class="alert alert-success alert-dismissible" role="alert">
                                  <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                  </div>
                              <?php endif; ?>
                              <?php if(Session::get('fail')): ?>
                              <div class="alert alert-danger alert-dismissible" role="alert">
                                  <strong>Oh Oops! </strong> <?php echo e(Session::get('fail')); ?>

                                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                              <?php endif; ?>
                          </div>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Telephone</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php $__currentLoopData = $UserInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $i++ ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td>
                          <i class="fab fa-bootstrap fa-lg text-primary me-3"></i> <strong><?php echo e($user->name); ?></strong>
                        </td>
                        <td><?php echo e($user->username); ?></td>
                        <td>
                          <a href="tel:<?php echo e($user->phone_number); ?>" class="btn btn-sm btn-outline-primary"> <?php echo e($user->phone_number); ?></a>
                        </td>
                        <td><a href="mailto:<?php echo e($user->email); ?>"><span class="badge bg-primary me-1"><?php echo e($user->email); ?></span></a></td>
                        <td><span class="badge <?php if($user->email_verified_at==""): ?><?php echo e('bg-danger'); ?> <?php else: ?> <?php echo e('bg-success'); ?> <?php endif; ?>"> 
                          <?php if($user->email_verified_at==""): ?> <?php echo e('Inactive'); ?> <?php else: ?> <?php echo e('Active'); ?> <?php endif; ?> 
                        </span></td>
                        <td>
                          <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="bx bx-dots-vertical-rounded"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="user_transaction_page/<?php echo e($user->id); ?>"
                                ><i class="bx bx-accessibility me-2"></i> Transactions</a
                              >
                              <?php if($user->email_verified_at == ""): ?>
                              <a class="dropdown-item" href="/disable_users_page/<?php echo e($user->id); ?>" onclick="return confirm('Are you sure to disable this user?')"
                                ><i class="bx bx-trash me-2"></i> Disable</a
                              ><?php endif; ?>
                              <?php if($user->email_verified_at != ""): ?>
                              <a class="dropdown-item" href="/activate_users_page/<?php echo e($user->id); ?>" onclick="return confirm('Are you sure to reactivate this user?')"
                                ><i class="bx bx-user-pin me-2"></i> Activate</a
                              ><?php endif; ?>
                              <a class="dropdown-item" href="/view_user_info/<?php echo e($user->id); ?>"
                                ><i class="bx bx-bullseye me-2"></i> View</a
                              >
                            </div>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- /Account -->
            </div>
            
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/admin/manage_users_page.blade.php ENDPATH**/ ?>