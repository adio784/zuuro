

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4">
    <span class="text-muted fw-light">Account Settings / </span> Countries
    </h4>

    <div class="row">
    <div class="col-md-12">
        <div class="row">
        
        <div class="col-md-7 col-12">
            <div class="card">
            <h5 class="card-header">Add Country</h5>
            <div class="card-body">
                <p>Connect with us on our social accounts</p>
                <!-- Social Accounts -->
                <div class="table-responsive">  
                    <table class="table"> 
                        <thead>
                            <th>#</th>
                            <th>Country</th>
                            <th>ISO3</th>
                            <th>Phonecode</th>
                            
                            
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $CountryInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $dt++; ?>
                                <tr>
                                    <td><?php echo e($dt); ?></td>
                                    <td><?php echo e($country->name); ?></td>
                                    <td><?php echo e($country->iso3); ?></td>
                                    <td><?php echo e($country->phonecode); ?></td>
                                    
                                    
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /Social Accounts -->
            </div>
            </div>
        </div>
        <div class="col-md-5 col-12 mb-md-0 mb-4">
            <div class="card">
            <h5 class="card-header">Add Country</h5>
            <div class="card-body">
                <p>Add new country who can use this service </p>
                <!-- Connections -->
                
                <div class="d-flex">
                    <form action="<?php echo e(route('manage_country_page')); ?>" id="country_form" method="post">
                        <?php echo csrf_field(); ?>
                    <!-- Result  -->
                <div id="result">
                    <?php if(Session::get('success')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <strong>Oh Oops! </strong> <?php echo e(Session::get('fail')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                    <?php endif; ?>
                </div>


                    <div class="row">
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Country Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="countryName"
                              name="countryName"
                              value="<?php echo e(old('countryName')); ?>"
                            />
                          </div><?php $__errorArgs = ['countryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Short Code</label>
                            <input
                              class="form-control"
                              type="text"
                              id="shortcode"
                              name="shortcode"
                              value="<?php echo e(old('shortcode')); ?>"
                              placeholder="NGN"
                            />
                          </div><?php $__errorArgs = ['shortcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Phone Code</label>
                            <input
                              class="form-control"
                              type="text"
                              id="phonecode"
                              name="phonecode"
                              value="<?php echo e(old('phonecode')); ?>"
                              placeholder="eg: +234"
                            />
                          </div><?php $__errorArgs = ['phonecode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Capital</label>
                            <input
                              class="form-control"
                              type="text"
                              id="capital"
                              name="capital"
                              value="<?php echo e(old('capital')); ?>"
                              placeholder="eg: Abuja"
                            />
                          </div><?php $__errorArgs = ['capital'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <div class="mb-3 col-md-6 col-lg-6">
                            <label for="firstName" class="form-label">Currency Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="currency"
                              name="currency"
                              value="<?php echo e(old('currency')); ?>"
                              placeholder="eg: N"
                            />
                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="mb-3 col-md-6 col-lg-6">
                            <label for="firstName" class="form-label">Currency Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="currency_name"
                              name="currency_name"
                              value="<?php echo e(old('currency_name')); ?>"
                              placeholder="eg: Naira"
                            />
                            <?php $__errorArgs = ['currency_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="mb-3 col-md-12 col-lg-12">
                            <button type="submit" class="btn btn-primary me-2">Submit</button>
                          </div>

                        </div>
                    </form>
                </div>
                <!-- /Connections -->
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/admin/manage_country_page.blade.php ENDPATH**/ ?>