

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Zuuro Loan/ </span> Support Page </h4>

    <div class="row">
        <div class="col-lg-6">
          <div class="card">
            <h5 class="card-header">Our Support Page</h5>
            <div class="card-body">
                <p>Connect with us on our social accounts</p>
                <!-- Social Accounts -->
                <?php $__currentLoopData = $PageInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="d-flex mb-3">
                    <div class="flex-shrink-0"><a href="<?php echo e($page->page_link); ?>" target="_blank">
                        <img src="<?php echo e($page->page_icon); ?>" alt="facebook" class="me-3" height="30"></a>
                    </div>
                    <div class="flex-grow-1 row">
                        <div class="col-8 col-sm-7 mb-sm-0 mb-2">
                        <h6 class="mb-0"><?php echo e($page->page_type); ?></h6>
                        <small class="text-muted"><?php echo e($page->page_name); ?></small>
                        </div>
                        <div class="col-4 col-sm-5 text-end">
                        <a href="support_page/<?php echo e($page->id); ?>" onclick="return confirm('Are you sure to delete ?')" class="btn btn-icon btn-outline-danger">
                            <i class="bx bx-trash-alt"></i>
                        </a>
                        </div>
                    </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- /Social Accounts -->
            </div>
          </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-4">
              <h5 class="card-header">Create Support Page For User ...</h5>
                    <!-- Data -->
                    
                    <hr class="my-0" />
                    <div class="card-body">
                      <form method="post" action="<?php echo e(route('support_page')); ?>">
                        <?php echo csrf_field(); ?>
                         <!-- Result  -->
                <div id="result">
                    <?php if(Session::get('success')): ?>
                    <div class="bs-toast toast fade show bg-success" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Success!</div>
                          <small><?php echo e(date('m')); ?></small>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                      </div>
                    <?php endif; ?>
                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <strong>Oh Oops! </strong> <?php echo e(Session::get('fail')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                    <?php endif; ?>
                </div>
                    <div class="row">
                    <div class="mb-3 col-md-12">
                            <label class="form-label" for="page">Page Type</label>
                            <select id="page" class="select2 form-select" name="page">
                              <option value="">-- Select page --</option>
                              <option> WhatsApp </option>
                              <option> Facebook </option>
                              <option> Twitter</option>
                              <option> LinkedIn</option>
                              <option> Yahoo Mail</option>
                              <option> Google Mail</option>
                              <option> Instagram</option>
                            </select>
                        </div>
                        <div class="mb-3 col-md-12">
                            <label class="form-label" for="page_name">Page Name</label>
                            <input type="text" id="page_name" class="form-control" name="page_name">
                          </div>

                          <div class="mb-3 col-md-12">
                            <label class="form-label" for="page_link">Page Link</label>
                            <textarea class="form-control" name="page_link" id="page_link"> </textarea>
                          </div>

                          <div class="mb-3 col-md-12">
                            <label class="form-label" for="page_icon">Page Icon</label>
                            <select id="page_icon" class="select2 form-select" name="page_icon">
                              <option value="">-- Select icon that match page name -- </option>
                              <option value="/img/icons/brands/whatsapp.png"> WhatsApp </option>
                              <option value="/img/icons/brands/facebook.png"> Facebook </option>
                              <option value="/img/icons/brands/twitter.png"> Twitter</option>
                              <option value="/img/icons/brands/linkedin.png"> LinkedIn</option>
                              <option value="/img/icons/brands/yahoomail.png"> Yahoo Mail</option>
                              <option value="/img/icons/brands/google.png"> Google Mail</option>
                              <option value="/img/icons/brands/instagram.png"> Instagram</option>
                            </select>
                        </div>

                        <div class="mt-2">
                          <button type="submit" class="btn btn-primary me-2">Submit</button>
                          <button type="reset" class="btn btn-outline-secondary">Clear all</button>
                        </div>
                      </form>
                    </div>
                    <!-- /Account -->
                  </div>
                 
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/admin/support_page.blade.php ENDPATH**/ ?>