

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 mt-4">
            <div class="card">
                <div class="card-header"><?php echo e(__('Create your 4 digit PIN')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(('create_pin')); ?>">
                        <?php echo csrf_field(); ?>
<!-- Result  -->
<div id="result234">
    <?php if(Session::get('success')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <strong>Suceess! </strong> <?php echo e(Session::get('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    
    <?php endif; ?>
    <?php if(Session::get('fail')): ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <strong>Oh Oops! </strong> <?php echo e(Session::get('fail')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>
</div>

                        <div class="row mb-3 mt-4">
                            <label for="pin" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Create PIN')); ?></label>

                            <div class="col-md-6">
                                <input id="pin" type="password" class="form-control <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pin" value="<?php echo e(old('pin')); ?>" required autocomplete="pin" autofocus>

                                <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="pin-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Confirm PIN')); ?></label>

                            <div class="col-md-6">
                                <input id="pin-confirm" type="password" class="form-control" name="pin_confirmation" required autocomplete="new-pin">
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Submit')); ?>

                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/user/transaction_pin.blade.php ENDPATH**/ ?>