

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4">
    <span class="text-muted fw-light">Account Settings / </span> Term of Use 
    </h4>

    <div class="row">
    <div class="col-md-12">
        <div class="row">
        <div class="col-md-12 col-12">
            <div class="card">
            <h5 class="card-header">Zuuro Telecommunication terms and condition</h5>
            <div class="card-body" style="height: 700px">
                <p>T & C </p>
                <!-- Social Accounts -->
                <div class="d-flex mb-3">
                    <iframe src="<?php echo e(asset('uploads/'.$TermofUse->fileName)); ?>" frameborder="0" width="100%" height="600px"></iframe>
                        
                </div>
                <!-- /Social Accounts -->
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/user/user_term_conditions.blade.php ENDPATH**/ ?>