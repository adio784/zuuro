

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><?php echo e('Input OTP sent to your number: '. session('phone_number')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(('verify_otp')); ?>">
                        <?php echo csrf_field(); ?>

                        <!-- Result  -->
                        <div id="error_result">
                            <?php if(Session::get('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show text-dark" role="alert">
                                    <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::get('fail')): ?>
                            <div class="alert alert-danger text-danger alert-dismissible fade show" role="alert">
                                <strong>Oh Oops!</strong> <?php echo e(Session::get('fail')); ?>

                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="row mb-3 mt-4">
                            <label for="verification_code" class="col-md-4 col-form-label text-md-end"><?php echo e(__('OTP')); ?></label>

                            <div class="col-md-6">
                                <input type="hidden" name="phone_number" value="<?php echo e(session('phone_number')); ?>">
                                <input id="verification_code" type="tel" class="form-control <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="verification_code" value="<?php echo e(old('verification_code')); ?>" required autocomplete="verification_code" autofocus>

                                <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/auth/input_verifymobile.blade.php ENDPATH**/ ?>