

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4">
    <span class="text-muted fw-light">QoinCo Loan/ </span> Payment Method
    </h4>

    <div class="row">
    <div class="col-md-12">
        <div class="row">
        
        <div class="col-md-7 col-12">
            <ul class="nav nav-pills flex-column flex-md-row mb-3">
                <li class="nav-item">
                    <a class="nav-link " href="/manage_debtors">
                      <i class="bx bx-user me-1"></i> Debtors</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="javascript:void(0);"
                    ><i class="bx bx-bell me-1"></i> Payment Method</a
                  >
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/late_loan_payment"
                    ><i class="bx bx-link-alt me-1"></i> Late Payment</a
                  >
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/sms_debtors_page"
                      ><i class="bx bx-link-alt me-1"></i> SMS Debtor</a
                    >
                  </li>
              </ul>
            <div class="card">
            <h5 class="card-header">Payment Methods</h5>
            <div class="card-body">
                <!-- Social Accounts -->
                <div class="table-responsive">  
                    <table class="table"  id="vertical-example"> 
                        <thead>
                            <th>#</th>
                            <th>Methods</th>
                            <th>Details</th>
                            <th>Status</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $PaymentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $dt++; ?>
                                <tr>
                                    <td><?php echo e($dt); ?></td>
                                    <td><?php echo e($pay->method); ?></td>
                                    <td><?php echo e($pay->details); ?></td>
                                    <td>
                                      <?php if($pay->status == 1): ?>
                                        <span class="badge bg-success"> Active </span>
                                      <?php else: ?>
                                        <span class="badge bg-danger"> In-Active </span>
                                       
                                      <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                            
                                            <a class="dropdown-item" href="loan_payment_method_page/<?php echo e($pay->id); ?>" onclick="return confirm('Are you sure to continue ?')"
                                                ><i class="bx bx-mouse-alt me-2"></i> <?php if($pay->status == 1): ?> Disable <?php else: ?> Enable <?php endif; ?></a
                                            >
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /Social Accounts -->
            </div>
            </div>
        </div>
        <div class="col-md-5 col-12 mb-md-0 mb-4">
            <div class="card">
            <h5 class="card-header">Add Payment Method</h5>
            <div class="card-body">
                <!-- Connections -->
                
                <div class="d-flex">
                    <form action="<?php echo e(route('loan_payment_method_page')); ?>"  method="post">
                        <?php echo csrf_field(); ?>

                    <!-- Result  -->
                <div id="result">
                    <?php if(Session::get('success')): ?>
                    <div class="bs-toast toast fade show bg-success" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Success!</div>
                          <small><?php echo e(date('m')); ?></small>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                      </div>
                    <?php endif; ?>
                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <strong>Oh Oops! </strong> <?php echo e(Session::get('fail')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                    <?php endif; ?>
                </div>


                    <div class="row">
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Method</label>
                            <input
                              class="form-control"
                              type="text"
                              id="payment_method"
                              name="payment_method"
                              value="<?php echo e(old('payment_method')); ?>"
                            />
                          </div><?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                          <div class="mb-3 col-md-12 col-lg-12">
                            <label for="firstName" class="form-label">Details</label>
                            <input
                              class="form-control"
                              type="text"
                              id="details"
                              name="details"
                              value="<?php echo e(old('details')); ?>"
                            />
                          </div><?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-sm"> <?php echo e($message); ?>  </span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         
                          <div class="mb-3 col-md-12 col-lg-12">
                            <button type="submit" class="btn btn-primary me-2">Submit</button>
                          </div>

                        </div>
                    </form>
                </div>
                <!-- /Connections -->
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qoinco\resources\views/app/admin/loan_payment_method_page.blade.php ENDPATH**/ ?>